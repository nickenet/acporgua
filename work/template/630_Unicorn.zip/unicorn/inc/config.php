<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'SmFKBqcwu6KwknAKusLuV3bS6');
    define('CONSUMER_SECRET', 'LmclAw03JcUqTWtxz6y7lzqn09TSfQmoVRtGIblPh7VRP9W8EM');

    // User Access Token
    define('ACCESS_TOKEN', '3068423449-QLELQByjMaiar9HgTxrVhQ6UZzfLaGFO9X51Ij1');
    define('ACCESS_SECRET', 'CboJvIVGDd18ogD8Zwhr1059kRvYMbjalbUyd3Kpc9wnm');